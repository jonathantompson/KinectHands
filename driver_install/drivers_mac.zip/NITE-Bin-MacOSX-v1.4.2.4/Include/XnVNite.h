/*******************************************************************************
*                                                                              *
*   PrimeSense NITE 1.3                                                        *
*   Copyright (C) 2010 PrimeSense Ltd.                                         *
*                                                                              *
*******************************************************************************/


#ifndef _XNV_NITE_H_
#define _XNV_NITE_H_

#include "XnVNiteFramework.h"
#include "XnVNiteControls.h"

#endif // _XNV_NITE_H_
